package com.demo.Repository.customRepo.impl;

import com.demo.DTO.HotelAvailabilityDTO;
import com.demo.Repository.customRepo.CustomHotelRepository;
import com.demo.Vo.Occupancy;
import jakarta.persistence.EntityManager;
import jakarta.persistence.PersistenceContext;
import org.springframework.stereotype.Repository;

import java.math.BigDecimal;
import java.time.LocalDate;
import java.util.List;
import java.util.stream.Collectors;

@Repository
public class CustomHotelRepositoryImpl implements CustomHotelRepository {


    @PersistenceContext
    private EntityManager entityManager;

    @Override
    public List<HotelAvailabilityDTO> getHotelAvailability(LocalDate startDate, LocalDate endDate , String city, Occupancy occupancy) {
            // Define the SQL query

            String sql = """
                    SELECT 
                        h.hotel_id, 
                        h.name AS hotel_name, 
                        h.city, 
                        h.country, 
                        h.star_rating, 
                        r.room_id, 
                        r.room_type, 
                        r.base_rate, 
                        r.currency, 
                        r.max_occupancy, 
                        ra.available_rooms, 
                        ra.dynamic_rate, 
                        p.adult_rate, 
                        p.child_rate
                    FROM Hotels h
                    JOIN Rooms r ON h.hotel_id = r.hotel_id
                    JOIN RoomAvailability ra ON r.room_id = ra.room_id
                    JOIN Pricing p ON r.room_id = p.room_id AND h.hotel_id = p.hotel_id
                    WHERE 
                        ra.available_from <= :startDate 
                        AND ra.available_to >= :endDate
                        AND h.available_from <= :startDate 
                        AND h.available_to >= :endDate
                        AND ra.available_rooms > 0
                        AND h.city = :hotelLocation  -- Filter by hotel location
                        AND r.max_occupancy > :minOccupancy  -- Filter by room occupancy
                    GROUP BY 
                        h.hotel_id, 
                        h.name, 
                        h.city, 
                        h.country, 
                        h.star_rating, 
                        r.room_id, 
                        r.room_type, 
                        r.base_rate, 
                        r.currency, 
                        r.max_occupancy, 
                        ra.available_rooms, 
                        ra.dynamic_rate, 
                        p.adult_rate, 
                        p.child_rate
                    ORDER BY 
                        h.hotel_id, 
                        r.room_id;
                """;

            // Execute the query and fetch the result list
            List<Object[]> results = entityManager.createNativeQuery(sql)
                    .setParameter("startDate", startDate)
                    .setParameter("endDate", endDate)
                    .setParameter("hotelLocation", city)
                    .setParameter("minOccupancy", occupancy.getTotal())
                    .getResultList();

            // Map the query results to a list of DTOs
            return results.stream()
                    .map(this::mapToHotelAvailabilityDTO)
                    .toList();
        }

        private HotelAvailabilityDTO mapToHotelAvailabilityDTO(Object[] result) {
            // Map each row of the result set to a HotelAvailabilityDTO object
            HotelAvailabilityDTO dto = new HotelAvailabilityDTO();
            dto.setHotelId((String) result[0]);
            dto.setHotelName((String) result[1]);
            dto.setCity((String) result[2]);
            dto.setCountry((String) result[3]);
            dto.setStarRating((Integer) result[4]);
            dto.setRoomId((String) result[5]);
            dto.setRoomType((String) result[6]);
            dto.setBaseRate((BigDecimal) result[7]);
            dto.setCurrency((String) result[8]);
            dto.setMaxOccupancy((Integer) result[9]);
            dto.setAvailableRooms((Integer) result[10]);
            dto.setDynamicRate((BigDecimal) result[11]);
            dto.setAdultRate((BigDecimal) result[12]);
            dto.setChildRate((BigDecimal) result[13]);
            return dto;
        }

}
