package com.demo.Vo;


import lombok.Builder;
import lombok.Data;
import lombok.Getter;
import lombok.Setter;

import java.math.BigDecimal;

@Data
@Getter
@Setter
@Builder
public class RoomAvailabilityResponse {
    private String roomId;
    private String roomType;
    private BigDecimal baseRate;
    private String currency;
    private int maxOccupancy;
    private int availableRooms;
    private price priceDetails;

}
