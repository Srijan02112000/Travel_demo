package com.demo.Vo;

import lombok.Data;
import lombok.Getter;
import lombok.Setter;

@Data
@Getter
@Setter
public class HotelSearchRequest {

     private String startDate,endDate;
     private String location;
     private int adult_occupancy;
     private int child_occupancy;
}
