package com.demo.Model;

import jakarta.persistence.*;
import lombok.*;

import java.math.BigDecimal;

@Entity
@Builder
@Data
@Getter
@Setter
@NoArgsConstructor
@AllArgsConstructor
@Table(name = "Pricing")
public class Pricing {

    @Id
    @Column(name = "pricing_id", length = 6, nullable = false, unique = true)
    private String pricingId; // 6-digit alphanumeric code

    @ManyToOne
    @JoinColumn(name = "room_id", nullable = false, referencedColumnName = "room_id", foreignKey = @ForeignKey(name = "fk_pricing_room"))
    private Room room; // Link to Rooms

    @ManyToOne
    @JoinColumn(name = "hotel_id", nullable = false, referencedColumnName = "hotel_id", foreignKey = @ForeignKey(name = "fk_pricing_hotel"))
    private Hotel hotel; // Link to Hotels

    @Column(name = "adult_rate", nullable = false, precision = 10, scale = 2)
    private BigDecimal adultRate;

    @Column(name = "child_rate", nullable = false, precision = 10, scale = 2)
    private BigDecimal childRate;
//    @Column(name = "adult_rate", nullable = false, precision = 10, scale = 2)
//    private Double adultRate;
//
//    @Column(name = "child_rate", nullable = false, precision = 10, scale = 2)
//    private Double childRate;

    // Getters and Setters
    // ...
}
