package com.demo.Model;

import jakarta.persistence.*;
import lombok.*;

import java.math.BigDecimal;

@Entity
@Builder
@Data
@Getter
@Setter
@NoArgsConstructor
@AllArgsConstructor
@Table(name = "Rooms")
public class Room {

    @Id
    @Column(name = "room_id", length = 6, nullable = false, unique = true)
    private String roomId; // 6-digit alphanumeric code

    @ManyToOne
    @JoinColumn(name = "hotel_id", nullable = false, referencedColumnName = "hotel_id", foreignKey = @ForeignKey(name = "fk_rooms_hotel"))
    private Hotel hotel; // Link to Hotels

    @Column(name = "room_type", length = 50, nullable = false)
    private String roomType; // Single, Double, Suite

    @Column(name = "amenities", columnDefinition = "jsonb")
    private String amenities; // JSONB stored as String in Java

    @Column(name = "base_rate", nullable = false, precision = 10, scale = 2)
    private BigDecimal baseRate;

    @Column(name = "currency", length = 10, nullable = false)
    private String currency;

    @Column(name = "max_occupancy", nullable = false)
    private int maxOccupancy;

    // Getters and Setters
    // ...
}

