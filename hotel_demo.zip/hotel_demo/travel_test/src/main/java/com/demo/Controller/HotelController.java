package com.demo.Controller;


import com.demo.DTO.HotelAvailabilityDTO;
import com.demo.Service.hotelSearchService;
import com.demo.Service.impl.hotelSearchServiceImpl;
import com.demo.Vo.HotelAvailabilityResponse;
import com.demo.Vo.HotelSearchRequest;
import com.demo.Vo.Occupancy;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.time.LocalDate;
import java.util.List;
import java.util.Objects;

@RestController
@RequestMapping("api/hotel")
public class HotelController {

    private final hotelSearchService hotelSearchService;

    public HotelController( com.demo.Service.hotelSearchService hotelSearchService) {
        this.hotelSearchService = hotelSearchService;
    }

    @PostMapping("/hotelAvailabilitySearch")
    public ResponseEntity<List<HotelAvailabilityResponse>> getHotelAvailability(
            @RequestBody HotelSearchRequest request){

        LocalDate start = LocalDate.parse(request.getStartDate());
        LocalDate end = LocalDate.parse(request.getEndDate());
        String city = Objects.nonNull(request.getLocation())  ? request.getLocation() : "New York";
        int adult_occupancy = request.getAdult_occupancy() != 0 ? request.getAdult_occupancy() : 1;
        int child_occupancy = request.getChild_occupancy() != 0 ? request.getChild_occupancy() : 0;
        Occupancy occupancy = Occupancy.builder()
                .adult(adult_occupancy)
                .child(child_occupancy)
                .total(adult_occupancy + child_occupancy)
                .build();
        List<HotelAvailabilityResponse> availability = hotelSearchService.getHotelAvailability(start, end , city, occupancy);
        return ResponseEntity.ok(availability);
    }

}
