package com.demo.Service.impl;

import com.demo.DTO.HotelAvailabilityDTO;
import com.demo.Repository.HotelRepository;
import com.demo.Repository.customRepo.CustomHotelRepository;
import com.demo.Service.hotelSearchService;
import com.demo.Vo.HotelAvailabilityResponse;
import com.demo.Vo.Occupancy;
import com.demo.Vo.RoomAvailabilityResponse;
import com.demo.Vo.price;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.math.BigDecimal;
import java.time.LocalDate;
import java.util.List;
import java.util.Map;
import java.util.stream.Collectors;

@Service
public class hotelSearchServiceImpl implements hotelSearchService {

    @Autowired
    private final CustomHotelRepository hotelRepository;

    public hotelSearchServiceImpl(CustomHotelRepository hotelRepository) {
        this.hotelRepository = hotelRepository;
    }


    @Override
    public List<HotelAvailabilityResponse> getHotelAvailability(LocalDate start, LocalDate end, String city,    Occupancy occupancy) {

        List<HotelAvailabilityDTO> result = hotelRepository.getHotelAvailability(start, end , city, occupancy);
        return transformAvailabilityResponse(result, occupancy);
    }
    public List<HotelAvailabilityResponse> transformAvailabilityResponse(List<HotelAvailabilityDTO> hotelAvailabilityDTOs,Occupancy occupancy) {
        Map<String, List<HotelAvailabilityDTO>> groupedByHotel = hotelAvailabilityDTOs.stream()
                .collect(Collectors.groupingBy(HotelAvailabilityDTO::getHotelId));

        // Mapping the grouped hotels to HotelAvailabilityResponse
        return groupedByHotel.entrySet().stream()
                .map(entry -> {
                    String hotelId = entry.getKey();
                    List<HotelAvailabilityDTO> hotelList = entry.getValue();

                    // Assuming that all rooms belong to the same hotel, so we can get the details from the first DTO
                    HotelAvailabilityDTO firstHotel = hotelList.get(0);

                    // Map hotel details
                    HotelAvailabilityResponse response = HotelAvailabilityResponse.builder()
                            .hotelId(hotelId)
                            .hotelName(firstHotel.getHotelName())
                            .city(firstHotel.getCity())
                            .country(firstHotel.getCountry())
                            .starRating(firstHotel.getStarRating())
                            .availableRooms(mapToRoomAvailabilityResponse(hotelList,occupancy))
                            .build();
                    return response;
                })
                .collect(Collectors.toList());
    }
    public List<RoomAvailabilityResponse> mapToRoomAvailabilityResponse(List<HotelAvailabilityDTO> hotelList , Occupancy occupancy) {
        return hotelList.stream()
                .map(dto -> RoomAvailabilityResponse.builder()
                        .roomId(dto.getRoomId())
                        .roomType(dto.getRoomType())
                        .baseRate(dto.getBaseRate())
                        .currency(dto.getCurrency() != null ? dto.getCurrency() : "USD")
                        .maxOccupancy(dto.getMaxOccupancy())
                        .availableRooms(dto.getAvailableRooms())
                        .priceDetails(getPriceDetails(dto.getAdultRate(),occupancy.getAdult(),dto.getChildRate(),occupancy.getChild()))
                        .build())
                .collect(Collectors.toList());
    }

    private price getPriceDetails(BigDecimal adultRate, int adultOccupancy, BigDecimal childRate, int childOccupancy) {
        BigDecimal totalAdultRate = adultRate.multiply(BigDecimal.valueOf(adultOccupancy));
        BigDecimal totalChildRate = childRate.multiply(BigDecimal.valueOf(childOccupancy));
        BigDecimal dyn_totalPrice = adultRate.add(totalChildRate);
        BigDecimal totalPrice = totalAdultRate.add(childRate);
        return price.builder()
                .totalAmount(totalPrice)
                .dynamicRate(dyn_totalPrice)
                .adultRate(totalAdultRate)
                .childRate(totalChildRate)
                .build();
    }
}
