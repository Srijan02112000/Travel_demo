package com.demo.Vo;


import lombok.*;

@Builder
@Data
@Getter
@Setter
@NoArgsConstructor
@AllArgsConstructor
public class RateVO {

    private String Amount;
    private String Currency;

}
