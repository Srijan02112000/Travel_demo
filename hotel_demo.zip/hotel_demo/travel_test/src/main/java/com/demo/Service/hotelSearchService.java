package com.demo.Service;


import com.demo.DTO.HotelAvailabilityDTO;
import com.demo.Vo.HotelAvailabilityResponse;
import com.demo.Vo.Occupancy;
import org.springframework.stereotype.Service;

import java.time.LocalDate;
import java.util.List;

@Service
public interface hotelSearchService {
    public List<HotelAvailabilityResponse> getHotelAvailability(LocalDate start, LocalDate end ,String city, Occupancy occupancy);
}
