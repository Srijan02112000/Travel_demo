package com.demo.Vo;

import lombok.*;

@Builder
@Data
@Getter
@Setter
@NoArgsConstructor
@AllArgsConstructor
public class Occupancy {
    private  int adult;
    private  int child;
    private  int total;
}
