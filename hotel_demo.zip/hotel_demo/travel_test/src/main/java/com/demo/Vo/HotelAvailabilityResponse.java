package com.demo.Vo;

import lombok.Builder;
import lombok.Data;
import lombok.Getter;
import lombok.Setter;

import java.math.BigDecimal;
import java.util.List;

@Data
@Getter
@Setter
@Builder

public class HotelAvailabilityResponse {
        private String hotelId;
        private String hotelName;
        private String city;
        private String country;
        private int starRating;
        private int adultCount;
        private int childCount;
        private List<RoomAvailabilityResponse> availableRooms;
}
