package com.demo.Vo;

import lombok.Builder;
import lombok.Data;
import lombok.Getter;
import lombok.Setter;

@Data
@Getter
@Setter
@Builder
public class HotelKey {

        private final String hotelId;
        private final String hotelName;
        private final String city;
        private final String country;
        private final int starRating;



        // Getters and hashCode, equals methods for proper grouping


}
