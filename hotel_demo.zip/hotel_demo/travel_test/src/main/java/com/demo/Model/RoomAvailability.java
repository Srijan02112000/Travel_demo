package com.demo.Model;

import jakarta.persistence.*;
import lombok.*;

import java.math.BigDecimal;
import java.time.LocalDate;

@Entity
@Builder
@Data
@Getter
@Setter
@NoArgsConstructor
@AllArgsConstructor
@Table(name = "RoomAvailability")
public class RoomAvailability {

    @Id
    @Column(name = "availability_id", length = 6, nullable = false, unique = true)
    private String availabilityId; // 6-digit alphanumeric code

    @ManyToOne
    @JoinColumn(name = "room_id", nullable = false, referencedColumnName = "room_id", foreignKey = @ForeignKey(name = "fk_roomavailability_room"))
    private Room room; // Link to Rooms

    @Column(name = "date", nullable = false)
    private LocalDate date;

    @Column(name = "available_rooms", nullable = false)
    private int availableRooms;

    @Column(name = "dynamic_rate", precision = 10, scale = 2)
    private BigDecimal dynamicRate;

    @Column(name = "available_from", nullable = false)
    private LocalDate availableFrom;

    @Column(name = "available_to", nullable = false)
    private LocalDate availableTo;

    // Getters and Setters
    // ..

}

