package com.demo.DTO;

import lombok.*;

import java.math.BigDecimal;

@Builder
@Data
@Getter
@Setter
@NoArgsConstructor
@AllArgsConstructor
public class HotelAvailabilityDTO {

    private String hotelId;
    private String hotelName;
    private String city;
    private String country;
    private int starRating;
    private String roomId;
    private String roomType;
    private BigDecimal baseRate;
    private String currency;
    private int maxOccupancy;
    private int availableRooms;
    private BigDecimal dynamicRate;
    private BigDecimal adultRate;
    private BigDecimal childRate;
}
