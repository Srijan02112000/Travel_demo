package com.demo.Vo;

import lombok.*;

import java.math.BigDecimal;
@Builder
@Data
@Getter
@Setter
@NoArgsConstructor
@AllArgsConstructor
public class price {
    private BigDecimal dynamicRate;
    private BigDecimal adultRate;
    private BigDecimal childRate;
    private String currency;
    private BigDecimal totalAmount;
}
