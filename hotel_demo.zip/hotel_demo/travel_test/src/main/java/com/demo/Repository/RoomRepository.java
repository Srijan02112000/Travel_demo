package com.demo.Repository;



import com.demo.Model.Room;
import org.springframework.data.jpa.repository.JpaRepository;

public interface RoomRepository  extends JpaRepository<Room, String> {

}
