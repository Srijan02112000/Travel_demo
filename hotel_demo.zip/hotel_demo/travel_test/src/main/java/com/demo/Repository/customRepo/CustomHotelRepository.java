package com.demo.Repository.customRepo;

import com.demo.DTO.HotelAvailabilityDTO;
import com.demo.Vo.Occupancy;

import java.time.LocalDate;
import java.util.List;

public interface CustomHotelRepository {

    List<HotelAvailabilityDTO> getHotelAvailability(LocalDate startDate, LocalDate endDate , String city, Occupancy occuppancy);
}
