package com.demo.Repository;

import com.demo.Model.Pricing;

import org.springframework.data.jpa.repository.JpaRepository;

public interface PricingRepository extends JpaRepository<Pricing, String> {
}
