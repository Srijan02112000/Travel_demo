package com.demo.Model;


import jakarta.persistence.Column;
import jakarta.persistence.Entity;
import jakarta.persistence.Id;
import jakarta.persistence.Table;
import lombok.*;

import java.time.LocalDate;

@Entity
@Builder
@Data
@Getter
@Setter
@NoArgsConstructor
@AllArgsConstructor
@Table(name = "hotels")
public class Hotel {

    @Id
    @Column(name = "hotel_id", length = 6, nullable = false, unique = true)
    private String hotelId; // 6-digit alphanumeric code

    @Column(name = "name", length = 100, nullable = false)
    private String name;

    @Column(name = "location", length = 200, nullable = false)
    private String location;

    @Column(name = "city", length = 50, nullable = false)
    private String city;

    @Column(name = "country", length = 50, nullable = false)
    private String country;

    @Column(name = "star_rating", nullable = false)
    private int starRating;

    @Column(name = "amenities", columnDefinition = "jsonb")
    private String amenities; // JSONB stored as String in Java

    @Column(name = "available_from", nullable = false)
    private LocalDate availableFrom;

    @Column(name = "available_to", nullable = false)
    private LocalDate availableTo;

    // Getters and Setters

}
